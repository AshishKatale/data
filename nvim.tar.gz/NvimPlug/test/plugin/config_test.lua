local M = {};
vim.test = M;

M.read_file_tostring = function(file_path)
  local file = io.open(file_path, "r");
  if (file == nil) then return "" end
  local content = file:read("*a");
  return content;
end

M.autotype_string = function(text, filetype, dt)
  vim.keymap.del('i', 'jk')
  if dt == nil then
    dt = 17;
  end
  if filetype ~= nil then
    vim.api.nvim_buf_set_option(0, "filetype", filetype);
  end

  local formatoptions = vim.api.nvim_get_option_value("formatoptions", { scope = "local" })
  vim.api.nvim_buf_set_option(0, "formatoptions", "");
  vim.api.nvim_buf_set_option(0, "smartindent", false);
  vim.api.nvim_buf_set_option(0, "autoindent", false);
  vim.diagnostic.disable();
  vim.api.nvim_command('startinsert');

  local char_list = vim.split(text, "");

  for i, c in ipairs(char_list) do
    vim.defer_fn(function() vim.api.nvim_feedkeys(c, "t", true) end, dt * i);
  end

  vim.defer_fn(
    function()
      vim.keymap.set({ "i" }, "jk", "<ESC>", { silent = true })
      vim.api.nvim_buf_set_option(0, "formatoptions", formatoptions);
      vim.api.nvim_buf_set_option(0, "smartindent", true);
      vim.api.nvim_buf_set_option(0, "autoindent", true);
      vim.diagnostic.enable();
    end,
    #char_list * dt + 300
  );
end

M.autotype_file = function(file_path, filetype, dt)
  local file = io.open(file_path, "r");
  if (file == nil) then
    return vim.print("Error reading file: " .. file_path)
  end
  vim.autotype_string(vim.read_file_tostring(file_path), filetype, dt)
end
