local M = {}

M.read_file_tostring = function(file_path)
  local file = io.open(file_path, "r");
  if (file == nil) then return "" end
  local content = file:read("*a");
  return content;
end

M.autotype_string = function(str, ft, dt)
  vim.keymap.del('i', 'jk')
  if dt == nil then
    dt = 17
  end
  if ft ~= nil then
    vim.api.nvim_buf_set_option(0, "filetype", ft);
  else
    vim.api.nvim_buf_set_option(0, "smartindent", false);
    vim.api.nvim_buf_set_option(0, "autoindent", false);
  end

  vim.api.nvim_command('startinsert')
  local t = 0;
  for line in str:gmatch("[^\n]+") do
    for i = 1, #line, 1 do
      local c = line:sub(i, i);
      t = t + dt;
      vim.defer_fn(function() vim.api.nvim_feedkeys(c, "t", true) end, t);
    end
    t = t + dt;
    vim.defer_fn(function() vim.api.nvim_feedkeys("\n", "t", true); end, t);
  end
  vim.defer_fn(function() vim.keymap.set({ "i" }, "jk", "<ESC>", { silent = true }) end, t + 300);
end

M.autotype_file = function(file_path, ft, dt)
  local file = io.open(file_path, "r");
  if (file == nil) then
    return vim.print("Error reading file: " .. file_path)
  end
  vim.autotype_string(vim.read_file_tostring(file_path), ft, dt)
end

return M;

